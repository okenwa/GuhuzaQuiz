"use client";

import { useState, useRef } from "react";
import { trackEvent } from "@/lib/analytics";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

type Report = import("@/lib/ai").ResumeInsightReport;

export default function ResumeReportPage() {
  const [resumeText, setResumeText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  const [fileMeta, setFileMeta] = useState<{ fileName?: string; mimeType?: string }>({});
  const [isDownloading, setIsDownloading] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const handleFile = async (file: File) => {
    if (!file) return;
    const name = file.name.toLowerCase();
    setFileMeta({ fileName: file.name, mimeType: file.type });
    try {
      if (name.endsWith(".pdf")) {
        const { parsePdfToText } = await import("@/lib/fileParsers");
        const text = await parsePdfToText(file);
        setResumeText(text);
        return;
      }
      if (name.endsWith(".docx")) {
        const { parseDocxToText } = await import("@/lib/fileParsers");
        const text = await parseDocxToText(file);
        setResumeText(text);
        return;
      }
      if (!file.type.includes("text") && !name.endsWith(".txt")) {
        setError("Supported formats: .txt, .pdf, .docx");
        return;
      }
      const text = await file.text();
      setResumeText(text);
    } catch (e: any) {
      setError(e?.message || "Failed to read file");
    }
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setReport(null);
    try {
      const res = await fetch("/api/resume/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText, fileName: fileMeta.fileName, mimeType: fileMeta.mimeType }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.message || "Failed to generate report");
      }
      const data = await res.json();
      setReport(data.report as Report);
      trackEvent("resume_report_generated", { length: resumeText.length });
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const downloadPDF = async () => {
    if (!reportRef.current || !report) return;
    
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      const fileName = `resume-report-${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(fileName);
      
      trackEvent("resume_report_downloaded", { fileName });
    } catch (error) {
      console.error("Error generating PDF:", error);
      setError("Failed to generate PDF. Please try again.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-2">Guhuza Resume Insight Report</h1>
      <p className="text-center text-gray-600 mb-6">Upload your resume or paste text to get AI-powered insights.</p>

      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Paste resume text</label>
          <textarea
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
            rows={10}
            className="w-full border rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Paste your resume here..."
          />
        </div>

        <div className="flex items-center gap-3">
          <label className="block text-sm font-medium">Or upload .txt/.pdf/.docx</label>
          <input
            type="file"
            accept=".txt,text/plain,.pdf,application/pdf,.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void handleFile(f);
            }}
            className="border p-2 rounded-md"
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || resumeText.trim().length < 50}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-md disabled:opacity-50"
        >
          {isLoading ? "Analyzing..." : "Generate Report"}
        </button>
      </form>

      {error && (
        <div className="mt-4 p-3 rounded-md bg-red-50 text-red-700 border border-red-200">{error}</div>
      )}

      {report && (
        <div className="mt-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Your Resume Report</h2>
            <button
              onClick={downloadPDF}
              disabled={isDownloading}
              className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-md disabled:opacity-50 flex items-center gap-2"
            >
              {isDownloading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Generating PDF...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Download PDF
                </>
              )}
            </button>
          </div>
          <div ref={reportRef}>
            <ReportView report={report} />
          </div>
        </div>
      )}
    </div>
  );
}

function ReportView({ report }: { report: Report }) {
  return (
    <div className="mt-8 space-y-6">
      <section className="bg-white rounded-lg shadow p-6 border">
        <h2 className="text-xl font-semibold mb-2">Summary</h2>
        <p className="text-gray-800">{report.summary}</p>
        <div className="mt-3 text-sm text-gray-600">File type: {report.fileType || "unknown"}</div>
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Strengths</h3>
          <ul className="list-disc pl-5 space-y-1">
            {report.strengths.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </section>

        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Gaps</h3>
          <ul className="list-disc pl-5 space-y-1">
            {report.gaps.map((g, i) => (
              <li key={i}>{g}</li>
            ))}
          </ul>
        </section>
      </div>

      <section className="bg-white rounded-lg shadow p-6 border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">ATS Readiness</h3>
          <span className="text-purple-700 font-bold">{report.atsScore}/100</span>
        </div>
        <div className="w-full bg-gray-100 h-2 rounded mt-2">
          <div
            className="bg-purple-600 h-2 rounded"
            style={{ width: `${Math.max(0, Math.min(100, report.atsScore))}%` }}
          />
        </div>
        {report.atsTips?.length ? (
          <ul className="list-disc pl-5 space-y-1 mt-3">
            {report.atsTips.map((t, i) => (
              <li key={i}>{t}</li>
            ))}
          </ul>
        ) : null}
      </section>

      <section className="bg-white rounded-lg shadow p-6 border">
        <h3 className="font-semibold mb-2">Contact Information</h3>
        <div className="text-sm text-gray-700 space-y-1">
          <div>Email present: {report.contactInfo?.hasEmail ? "Yes" : "No"}</div>
          <div>Phone present: {report.contactInfo?.hasPhone ? "Yes" : "No"}</div>
          <div>LinkedIn present: {report.contactInfo?.hasLinkedIn ? "Yes" : "No"}</div>
          {report.contactInfo?.extracted ? (
            <div className="text-gray-600">
              {report.contactInfo.extracted.email && <div>Email: {report.contactInfo.extracted.email}</div>}
              {report.contactInfo.extracted.phone && <div>Phone: {report.contactInfo.extracted.phone}</div>}
              {report.contactInfo.extracted.linkedin && <div>LinkedIn: {report.contactInfo.extracted.linkedin}</div>}
            </div>
          ) : null}
        </div>
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Date Formatting</h3>
          <div className="text-sm text-gray-700">Pattern: {report.dateFormatting?.pattern || "—"}</div>
          <div className="text-sm text-gray-700">Consistency: {report.dateFormatting?.consistency || "—"}</div>
        </section>
        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Measurable Results</h3>
          <div className="text-sm text-gray-700">Present: {report.measurableResults?.present ? "Yes" : "No"}</div>
          {report.measurableResults?.examples?.length ? (
            <ul className="list-disc pl-5 space-y-1 mt-2">
              {report.measurableResults.examples.map((ex, i) => (
                <li key={i}>{ex}</li>
              ))}
            </ul>
          ) : null}
        </section>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Resume Tone</h3>
          <div className="text-sm text-gray-700">{report.resumeTone || "—"}</div>
        </section>
        <section className="bg-white rounded-lg shadow p-6 border">
          <h3 className="font-semibold mb-2">Web Presence</h3>
          {report.webPresence?.links?.length ? (
            <ul className="list-disc pl-5 space-y-1">
              {report.webPresence.links.map((l, i) => (
                <li key={i}><a href={l} target="_blank" className="text-purple-700 underline">{l}</a></li>
              ))}
            </ul>
          ) : <div className="text-sm text-gray-700">No links detected</div>}
          {report.webPresence?.suggestions?.length ? (
            <ul className="list-disc pl-5 space-y-1 mt-2">
              {report.webPresence.suggestions.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          ) : null}
        </section>
      </div>

      <section className="bg-white rounded-lg shadow p-6 border">
        <h3 className="font-semibold mb-2">Formatting Audit</h3>
        <div className="text-sm text-gray-700">Font consistency: {report.formattingAudit?.fontConsistency || "—"}</div>
        <div className="text-sm text-gray-700">Layout: {report.formattingAudit?.layout || "—"}</div>
        <div className="text-sm text-gray-700">Page setup: {report.formattingAudit?.pageSetup || "—"}</div>
        {report.formattingAudit?.suggestions?.length ? (
          <ul className="list-disc pl-5 space-y-1 mt-2">
            {report.formattingAudit.suggestions.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        ) : null}
      </section>

      <section className="bg-white rounded-lg shadow p-6 border">
        <h3 className="font-semibold mb-2">Tailoring Tips</h3>
        <div className="space-y-4">
          {report.tailoringTips.map((section, idx) => (
            <div key={idx}>
              <h4 className="font-medium mb-1">{section.title}</h4>
              <ul className="list-disc pl-5 space-y-1">
                {section.bullets.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white rounded-lg shadow p-6 border">
        <h3 className="font-semibold mb-2">Action Items</h3>
        <ol className="list-decimal pl-5 space-y-1">
          {report.actionItems.map((a, i) => (
            <li key={i}>{a}</li>
          ))}
        </ol>
      </section>
    </div>
  );
}


